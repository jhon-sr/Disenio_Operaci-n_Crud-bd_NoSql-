import tkinter as tk
from tkinter import messagebox

# Colores y estilos
bg_color = "#001f3f"        # Color de fondo principal
fg_color = "#ffffff"        # Color de texto principal
button_color = "#0074D9"    # Color de botones
frame_color = "#001f4f"     # Color de fondo de los marcos
section_bg_color = "#001f5f" # Color de fondo de las secciones

def create_main_window():
    # Crear la ventana principal
    root = tk.Tk()
    root.title("Microfútbol")
    root.geometry("1200x600")
    root.configure(bg=bg_color)  # Fondo azul oscuro

    # Crear el marco del menú superior
    menu_frame = tk.Frame(root, bg=frame_color)
    menu_frame.pack(side="top", fill="x")

    # Agregar botones al menú
    menu_buttons = ["Árbitros", "Deportistas", "Encuentros Deportivos", "Entrenadores", "Equipos", "Tabla de Posiciones", "Salir"]
    for btn_text in menu_buttons:
        btn = tk.Button(menu_frame, text=btn_text, bg=button_color, fg=fg_color, font=("Arial", 12), relief="flat", command=lambda t=btn_text: display_section(t))
        btn.pack(side="left", padx=5, pady=5)

    # Crear un marco para el contenido principal
    content_frame = tk.Frame(root, bg=section_bg_color)
    content_frame.pack(side="top", fill="both", expand=True, padx=10, pady=10)

    # Función para mostrar diferentes secciones
    def display_section(section):
        for widget in content_frame.winfo_children():
            widget.destroy()
        label = tk.Label(content_frame, text=f"Sección: {section}", font=("Arial", 16), bg=section_bg_color, fg=fg_color)
        label.pack(pady=20)

        # Añadir contenido específico para cada sección
        if section == "Árbitros":
            display_arbitros(content_frame)
        elif section == "Deportistas":
            display_deportistas(content_frame)
        elif section == "Encuentros Deportivos":
            display_encuentros(content_frame)
        elif section == "Entrenadores":
            display_entrenadores(content_frame)
        elif section == "Equipos":
            display_equipos(content_frame)
        elif section == "Tabla de Posiciones":
            display_tabla(content_frame)
        elif section == "Salir":
            root.quit()

    def display_arbitros(frame):
        tk.Label(frame, text="Gestión de Árbitros", font=("Arial", 14), bg=section_bg_color, fg=fg_color).pack(pady=10)
        tk.Button(frame, text="Crear Árbitro", command=create_arbitro, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Todos los Árbitros", command=read_arbitros, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Árbitro por ID", command=read_arbitro_by_id, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Actualizar Árbitro", command=update_arbitro, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Eliminar Árbitro", command=delete_arbitro, bg=button_color, fg=fg_color).pack(pady=5)

    def display_deportistas(frame):
        tk.Label(frame, text="Gestión de Deportistas", font=("Arial", 14), bg=section_bg_color, fg=fg_color).pack(pady=10)
        tk.Button(frame, text="Crear Deportista", command=create_deportista, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Todos los Deportistas", command=read_deportistas, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Deportista por ID", command=read_deportista_by_id, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Actualizar Deportista", command=update_deportista, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Eliminar Deportista", command=delete_deportista, bg=button_color, fg=fg_color).pack(pady=5)

    def display_encuentros(frame):
        tk.Label(frame, text="Gestión de Encuentros Deportivos", font=("Arial", 14), bg=section_bg_color, fg=fg_color).pack(pady=10)
        tk.Button(frame, text="Crear Encuentro Deportivo", command=create_encuentro, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Todos los Encuentros Deportivos", command=read_encuentros, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Encuentro Deportivo por ID", command=read_encuentro_by_id, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Actualizar Encuentro Deportivo", command=update_encuentro, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Eliminar Encuentro Deportivo", command=delete_encuentro, bg=button_color, fg=fg_color).pack(pady=5)

    def display_entrenadores(frame):
        tk.Label(frame, text="Gestión de Entrenadores", font=("Arial", 14), bg=section_bg_color, fg=fg_color).pack(pady=10)
        tk.Button(frame, text="Crear Entrenador", command=create_entrenador, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Todos los Entrenadores", command=read_entrenadores, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Entrenador por ID", command=read_entrenador_by_id, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Actualizar Entrenador", command=update_entrenador, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Eliminar Entrenador", command=delete_entrenador, bg=button_color, fg=fg_color).pack(pady=5)

    def display_equipos(frame):
        tk.Label(frame, text="Gestión de Equipos", font=("Arial", 14), bg=section_bg_color, fg=fg_color).pack(pady=10)
        tk.Button(frame, text="Crear Equipo", command=create_equipo, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Todos los Equipos", command=read_equipos, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Leer Equipo por ID", command=read_equipo_by_id, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Actualizar Equipo", command=update_equipo, bg=button_color, fg=fg_color).pack(pady=5)
        tk.Button(frame, text="Eliminar Equipo", command=delete_equipo, bg=button_color, fg=fg_color).pack(pady=5)

    def display_tabla(frame):
        tk.Label(frame, text="Tabla de Posiciones", font=("Arial", 14), bg=section_bg_color, fg=fg_color).pack(pady=10)
        tk.Button(frame, text="Actualizar Tabla de Posiciones", command=update_tabla, bg=button_color, fg=fg_color).pack(pady=5)

    # Funciones CRUD para Árbitros
    def create_arbitro():
        def submit():
            nombre = entry_nombre.get()
            nacionalidad = entry_nacionalidad.get()
            messagebox.showinfo("Éxito", f"Árbitro creado: {nombre}, {nacionalidad}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Crear Árbitro")
        form.configure(bg=bg_color)

        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Nacionalidad:", bg=bg_color, fg=fg_color).grid(row=2, column=0)

        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nacionalidad = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_nombre.grid(row=1, column=1)
        entry_nacionalidad.grid(row=2, column=1)

        tk.Button(form, text="Crear", command=submit, bg=button_color, fg=fg_color).grid(row=3, column=0, columnspan=2)

    def read_arbitros():
        form = tk.Toplevel(root)
        form.title("Lista de Árbitros")
        form.configure(bg=bg_color)
        
        # Simulación de datos
        arbitros = [
            {"nombre": "Árbitro 1", "nacionalidad": "Nacionalidad 1"},
            {"nombre": "Árbitro 2", "nacionalidad": "Nacionalidad 2"}
        ]
        
        for i, arbitro in enumerate(arbitros):
            tk.Label(form, text=f"Nombre: {arbitro['nombre']}, Nacionalidad: {arbitro['nacionalidad']}", bg=bg_color, fg=fg_color).grid(row=i, column=0)

    def read_arbitro_by_id():
        def submit():
            arbitro_id = entry_id.get()
            # Simulación de datos
            arbitros = {
                "1": {"nombre": "Árbitro 1", "nacionalidad": "Nacionalidad 1"},
                "2": {"nombre": "Árbitro 2", "nacionalidad": "Nacionalidad 2"}
            }
            arbitro = arbitros.get(arbitro_id)
            if arbitro:
                messagebox.showinfo("Resultado", f"Nombre: {arbitro['nombre']}, Nacionalidad: {arbitro['nacionalidad']}")
            else:
                messagebox.showerror("Error", "Árbitro no encontrado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Leer Árbitro por ID")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Árbitro:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Buscar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    def update_arbitro():
        def submit():
            arbitro_id = entry_id.get()
            nombre = entry_nombre.get()
            nacionalidad = entry_nacionalidad.get()
            messagebox.showinfo("Éxito", f"Árbitro actualizado: {nombre}, {nacionalidad}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Actualizar Árbitro")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Árbitro:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Nacionalidad:", bg=bg_color, fg=fg_color).grid(row=2, column=0)

        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nacionalidad = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_id.grid(row=0, column=1)
        entry_nombre.grid(row=1, column=1)
        entry_nacionalidad.grid(row=2, column=1)

        tk.Button(form, text="Actualizar", command=submit, bg=button_color, fg=fg_color).grid(row=3, column=0, columnspan=2)

    def delete_arbitro():
        def submit():
            arbitro_id = entry_id.get()
            messagebox.showinfo("Éxito", f"Árbitro con ID {arbitro_id} eliminado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Eliminar Árbitro")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Árbitro:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Eliminar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    # Funciones CRUD para Deportistas
    def create_deportista():
        def submit():
            nombre = entry_nombre.get()
            fecha_nacimiento = entry_fecha_nacimiento.get()
            nacionalidad = entry_nacionalidad.get()
            posicion = entry_posicion.get()
            numero_camiseta = entry_numero_camiseta.get()
            equipo_id = entry_equipo_id.get()
            messagebox.showinfo("Éxito", f"Deportista creado: {nombre}, {nacionalidad}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Crear Deportista")
        form.configure(bg=bg_color)

        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Fecha de Nacimiento:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="Nacionalidad:", bg=bg_color, fg=fg_color).grid(row=3, column=0)
        tk.Label(form, text="Posición:", bg=bg_color, fg=fg_color).grid(row=4, column=0)
        tk.Label(form, text="Número de Camiseta:", bg=bg_color, fg=fg_color).grid(row=5, column=0)
        tk.Label(form, text="ID del Equipo:", bg=bg_color, fg=fg_color).grid(row=6, column=0)

        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_fecha_nacimiento = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nacionalidad = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_posicion = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_numero_camiseta = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_equipo_id = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_nombre.grid(row=1, column=1)
        entry_fecha_nacimiento.grid(row=2, column=1)
        entry_nacionalidad.grid(row=3, column=1)
        entry_posicion.grid(row=4, column=1)
        entry_numero_camiseta.grid(row=5, column=1)
        entry_equipo_id.grid(row=6, column=1)

        tk.Button(form, text="Crear", command=submit, bg=button_color, fg=fg_color).grid(row=7, column=0, columnspan=2)

    def read_deportistas():
        form = tk.Toplevel(root)
        form.title("Lista de Deportistas")
        form.configure(bg=bg_color)
        
        # Simulación de datos
        deportistas = [
            {"nombre": "Deportista 1", "nacionalidad": "Nacionalidad 1"},
            {"nombre": "Deportista 2", "nacionalidad": "Nacionalidad 2"}
        ]
        
        for i, deportista in enumerate(deportistas):
            tk.Label(form, text=f"Nombre: {deportista['nombre']}, Nacionalidad: {deportista['nacionalidad']}", bg=bg_color, fg=fg_color).grid(row=i, column=0)

    def read_deportista_by_id():
        def submit():
            deportista_id = entry_id.get()
            # Simulación de datos
            deportistas = {
                "1": {"nombre": "Deportista 1", "nacionalidad": "Nacionalidad 1"},
                "2": {"nombre": "Deportista 2", "nacionalidad": "Nacionalidad 2"}
            }
            deportista = deportistas.get(deportista_id)
            if deportista:
                messagebox.showinfo("Resultado", f"Nombre: {deportista['nombre']}, Nacionalidad: {deportista['nacionalidad']}")
            else:
                messagebox.showerror("Error", "Deportista no encontrado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Leer Deportista por ID")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Deportista:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Buscar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    def update_deportista():
        def submit():
            deportista_id = entry_id.get()
            nombre = entry_nombre.get()
            fecha_nacimiento = entry_fecha_nacimiento.get()
            nacionalidad = entry_nacionalidad.get()
            posicion = entry_posicion.get()
            numero_camiseta = entry_numero_camiseta.get()
            equipo_id = entry_equipo_id.get()
            messagebox.showinfo("Éxito", f"Deportista actualizado: {nombre}, {nacionalidad}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Actualizar Deportista")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Deportista:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Fecha de Nacimiento:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="Nacionalidad:", bg=bg_color, fg=fg_color).grid(row=3, column=0)
        tk.Label(form, text="Posición:", bg=bg_color, fg=fg_color).grid(row=4, column=0)
        tk.Label(form, text="Número de Camiseta:", bg=bg_color, fg=fg_color).grid(row=5, column=0)
        tk.Label(form, text="ID del Equipo:", bg=bg_color, fg=fg_color).grid(row=6, column=0)

        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_fecha_nacimiento = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nacionalidad = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_posicion = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_numero_camiseta = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_equipo_id = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_id.grid(row=0, column=1)
        entry_nombre.grid(row=1, column=1)
        entry_fecha_nacimiento.grid(row=2, column=1)
        entry_nacionalidad.grid(row=3, column=1)
        entry_posicion.grid(row=4, column=1)
        entry_numero_camiseta.grid(row=5, column=1)
        entry_equipo_id.grid(row=6, column=1)

        tk.Button(form, text="Actualizar", command=submit, bg=button_color, fg=fg_color).grid(row=7, column=0, columnspan=2)

    def delete_deportista():
        def submit():
            deportista_id = entry_id.get()
            messagebox.showinfo("Éxito", f"Deportista con ID {deportista_id} eliminado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Eliminar Deportista")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Deportista:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Eliminar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    # Funciones CRUD para Encuentros Deportivos
    def create_encuentro():
        def submit():
            fecha = entry_fecha.get()
            hora = entry_hora.get()
            estadio = entry_estadio.get()
            equipo_local_id = entry_equipo_local_id.get()
            equipo_visitante_id = entry_equipo_visitante_id.get()
            arbitro_id = entry_arbitro_id.get()
            messagebox.showinfo("Éxito", f"Encuentro Deportivo creado en {estadio}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Crear Encuentro Deportivo")
        form.configure(bg=bg_color)

        tk.Label(form, text="Fecha:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Hora:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="Estadio:", bg=bg_color, fg=fg_color).grid(row=3, column=0)
        tk.Label(form, text="ID del Equipo Local:", bg=bg_color, fg=fg_color).grid(row=4, column=0)
        tk.Label(form, text="ID del Equipo Visitante:", bg=bg_color, fg=fg_color).grid(row=5, column=0)
        tk.Label(form, text="ID del Árbitro:", bg=bg_color, fg=fg_color).grid(row=6, column=0)

        entry_fecha = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_hora = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_estadio = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_equipo_local_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_equipo_visitante_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_arbitro_id = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_fecha.grid(row=1, column=1)
        entry_hora.grid(row=2, column=1)
        entry_estadio.grid(row=3, column=1)
        entry_equipo_local_id.grid(row=4, column=1)
        entry_equipo_visitante_id.grid(row=5, column=1)
        entry_arbitro_id.grid(row=6, column=1)

        tk.Button(form, text="Crear", command=submit, bg=button_color, fg=fg_color).grid(row=7, column=0, columnspan=2)

    def read_encuentros():
        form = tk.Toplevel(root)
        form.title("Lista de Encuentros Deportivos")
        form.configure(bg=bg_color)
        
        # Simulación de datos
        encuentros = [
            {"estadio": "Estadio 1", "fecha": "2023-06-15"},
            {"estadio": "Estadio 2", "fecha": "2023-07-20"}
        ]
        
        for i, encuentro in enumerate(encuentros):
            tk.Label(form, text=f"Estadio: {encuentro['estadio']}, Fecha: {encuentro['fecha']}", bg=bg_color, fg=fg_color).grid(row=i, column=0)

    def read_encuentro_by_id():
        def submit():
            encuentro_id = entry_id.get()
            # Simulación de datos
            encuentros = {
                "1": {"estadio": "Estadio 1", "fecha": "2023-06-15"},
                "2": {"estadio": "Estadio 2", "fecha": "2023-07-20"}
            }
            encuentro = encuentros.get(encuentro_id)
            if encuentro:
                messagebox.showinfo("Resultado", f"Estadio: {encuentro['estadio']}, Fecha: {encuentro['fecha']}")
            else:
                messagebox.showerror("Error", "Encuentro no encontrado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Leer Encuentro Deportivo por ID")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Encuentro Deportivo:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Buscar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    def update_encuentro():
        def submit():
            encuentro_id = entry_id.get()
            fecha = entry_fecha.get()
            hora = entry_hora.get()
            estadio = entry_estadio.get()
            equipo_local_id = entry_equipo_local_id.get()
            equipo_visitante_id = entry_equipo_visitante_id.get()
            arbitro_id = entry_arbitro_id.get()
            messagebox.showinfo("Éxito", f"Encuentro Deportivo actualizado en {estadio}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Actualizar Encuentro Deportivo")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Encuentro Deportivo:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        tk.Label(form, text="Fecha:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Hora:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="Estadio:", bg=bg_color, fg=fg_color).grid(row=3, column=0)
        tk.Label(form, text="ID del Equipo Local:", bg=bg_color, fg=fg_color).grid(row=4, column=0)
        tk.Label(form, text="ID del Equipo Visitante:", bg=bg_color, fg=fg_color).grid(row=5, column=0)
        tk.Label(form, text="ID del Árbitro:", bg=bg_color, fg=fg_color).grid(row=6, column=0)

        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_fecha = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_hora = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_estadio = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_equipo_local_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_equipo_visitante_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_arbitro_id = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_id.grid(row=0, column=1)
        entry_fecha.grid(row=1, column=1)
        entry_hora.grid(row=2, column=1)
        entry_estadio.grid(row=3, column=1)
        entry_equipo_local_id.grid(row=4, column=1)
        entry_equipo_visitante_id.grid(row=5, column=1)
        entry_arbitro_id.grid(row=6, column=1)

        tk.Button(form, text="Actualizar", command=submit, bg=button_color, fg=fg_color).grid(row=7, column=0, columnspan=2)

    def delete_encuentro():
        def submit():
            encuentro_id = entry_id.get()
            messagebox.showinfo("Éxito", f"Encuentro Deportivo con ID {encuentro_id} eliminado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Eliminar Encuentro Deportivo")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Encuentro Deportivo:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Eliminar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    # Funciones CRUD para Entrenadores
    def create_entrenador():
        def submit():
            nombre = entry_nombre.get()
            nacionalidad = entry_nacionalidad.get()
            fecha_nacimiento = entry_fecha_nacimiento.get()
            messagebox.showinfo("Éxito", f"Entrenador creado: {nombre}, {nacionalidad}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Crear Entrenador")
        form.configure(bg=bg_color)

        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Nacionalidad:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="Fecha de Nacimiento:", bg=bg_color, fg=fg_color).grid(row=3, column=0)

        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nacionalidad = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_fecha_nacimiento = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_nombre.grid(row=1, column=1)
        entry_nacionalidad.grid(row=2, column=1)
        entry_fecha_nacimiento.grid(row=3, column=1)

        tk.Button(form, text="Crear", command=submit, bg=button_color, fg=fg_color).grid(row=4, column=0, columnspan=2)

    def read_entrenadores():
        form = tk.Toplevel(root)
        form.title("Lista de Entrenadores")
        form.configure(bg=bg_color)
        
        # Simulación de datos
        entrenadores = [
            {"nombre": "Entrenador 1", "nacionalidad": "Nacionalidad 1"},
            {"nombre": "Entrenador 2", "nacionalidad": "Nacionalidad 2"}
        ]
        
        for i, entrenador in enumerate(entrenadores):
            tk.Label(form, text=f"Nombre: {entrenador['nombre']}, Nacionalidad: {entrenador['nacionalidad']}", bg=bg_color, fg=fg_color).grid(row=i, column=0)

    def read_entrenador_by_id():
        def submit():
            entrenador_id = entry_id.get()
            # Simulación de datos
            entrenadores = {
                "1": {"nombre": "Entrenador 1", "nacionalidad": "Nacionalidad 1"},
                "2": {"nombre": "Entrenador 2", "nacionalidad": "Nacionalidad 2"}
            }
            entrenador = entrenadores.get(entrenador_id)
            if entrenador:
                messagebox.showinfo("Resultado", f"Nombre: {entrenador['nombre']}, Nacionalidad: {entrenador['nacionalidad']}")
            else:
                messagebox.showerror("Error", "Entrenador no encontrado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Leer Entrenador por ID")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Entrenador:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Buscar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    def update_entrenador():
        def submit():
            entrenador_id = entry_id.get()
            nombre = entry_nombre.get()
            nacionalidad = entry_nacionalidad.get()
            fecha_nacimiento = entry_fecha_nacimiento.get()
            messagebox.showinfo("Éxito", f"Entrenador actualizado: {nombre}, {nacionalidad}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Actualizar Entrenador")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Entrenador:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="Nacionalidad:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="Fecha de Nacimiento:", bg=bg_color, fg=fg_color).grid(row=3, column=0)

        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nacionalidad = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_fecha_nacimiento = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_id.grid(row=0, column=1)
        entry_nombre.grid(row=1, column=1)
        entry_nacionalidad.grid(row=2, column=1)
        entry_fecha_nacimiento.grid(row=3, column=1)

        tk.Button(form, text="Actualizar", command=submit, bg=button_color, fg=fg_color).grid(row=4, column=0, columnspan=2)

    def delete_entrenador():
        def submit():
            entrenador_id = entry_id.get()
            messagebox.showinfo("Éxito", f"Entrenador con ID {entrenador_id} eliminado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Eliminar Entrenador")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Entrenador:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Eliminar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    # Funciones CRUD para Equipos
    def create_equipo():
        def submit():
            nombre = entry_nombre.get()
            pais = entry_pais.get()
            entrenador_id = entry_entrenador_id.get()
            messagebox.showinfo("Éxito", f"Equipo creado: {nombre}, {pais}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Crear Equipo")
        form.configure(bg=bg_color)

        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="País:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="ID del Entrenador:", bg=bg_color, fg=fg_color).grid(row=3, column=0)

        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_pais = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_entrenador_id = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_nombre.grid(row=1, column=1)
        entry_pais.grid(row=2, column=1)
        entry_entrenador_id.grid(row=3, column=1)

        tk.Button(form, text="Crear", command=submit, bg=button_color, fg=fg_color).grid(row=4, column=0, columnspan=2)

    def read_equipos():
        form = tk.Toplevel(root)
        form.title("Lista de Equipos")
        form.configure(bg=bg_color)
        
        # Simulación de datos
        equipos = [
            {"nombre": "Equipo 1", "pais": "País 1"},
            {"nombre": "Equipo 2", "pais": "País 2"}
        ]
        
        for i, equipo in enumerate(equipos):
            tk.Label(form, text=f"Nombre: {equipo['nombre']}, País: {equipo['pais']}", bg=bg_color, fg=fg_color).grid(row=i, column=0)

    def read_equipo_by_id():
        def submit():
            equipo_id = entry_id.get()
            # Simulación de datos
            equipos = {
                "1": {"nombre": "Equipo 1", "pais": "País 1"},
                "2": {"nombre": "Equipo 2", "pais": "País 2"}
            }
            equipo = equipos.get(equipo_id)
            if equipo:
                messagebox.showinfo("Resultado", f"Nombre: {equipo['nombre']}, País: {equipo['pais']}")
            else:
                messagebox.showerror("Error", "Equipo no encontrado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Leer Equipo por ID")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Equipo:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Buscar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    def update_equipo():
        def submit():
            equipo_id = entry_id.get()
            nombre = entry_nombre.get()
            pais = entry_pais.get()
            entrenador_id = entry_entrenador_id.get()
            messagebox.showinfo("Éxito", f"Equipo actualizado: {nombre}, {pais}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Actualizar Equipo")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Equipo:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        tk.Label(form, text="Nombre:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="País:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="ID del Entrenador:", bg=bg_color, fg=fg_color).grid(row=3, column=0)

        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_nombre = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_pais = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_entrenador_id = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_id.grid(row=0, column=1)
        entry_nombre.grid(row=1, column=1)
        entry_pais.grid(row=2, column=1)
        entry_entrenador_id.grid(row=3, column=1)

        tk.Button(form, text="Actualizar", command=submit, bg=button_color, fg=fg_color).grid(row=4, column=0, columnspan=2)

    def delete_equipo():
        def submit():
            equipo_id = entry_id.get()
            messagebox.showinfo("Éxito", f"Equipo con ID {equipo_id} eliminado")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Eliminar Equipo")
        form.configure(bg=bg_color)

        tk.Label(form, text="ID del Equipo:", bg=bg_color, fg=fg_color).grid(row=0, column=0)
        entry_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_id.grid(row=0, column=1)

        tk.Button(form, text="Eliminar", command=submit, bg=button_color, fg=fg_color).grid(row=1, column=0, columnspan=2)

    # Funciones CRUD para Tabla de Posiciones
    def update_tabla():
        def submit():
            jornada = entry_jornada.get()
            equipo_id = entry_equipo_id.get()
            partidos_jugados = entry_partidos_jugados.get()
            partidos_ganados = entry_partidos_ganados.get()
            partidos_empatados = entry_partidos_empatados.get()
            partidos_perdidos = entry_partidos_perdidos.get()
            goles_a_favor = entry_goles_a_favor.get()
            goles_en_contra = entry_goles_en_contra.get()
            puntos = entry_puntos.get()
            messagebox.showinfo("Éxito", f"Tabla de posiciones actualizada para la jornada {jornada}")
            form.destroy()

        form = tk.Toplevel(root)
        form.title("Actualizar Tabla de Posiciones")
        form.configure(bg=bg_color)

        tk.Label(form, text="Jornada:", bg=bg_color, fg=fg_color).grid(row=1, column=0)
        tk.Label(form, text="ID del Equipo:", bg=bg_color, fg=fg_color).grid(row=2, column=0)
        tk.Label(form, text="Partidos Jugados:", bg=bg_color, fg=fg_color).grid(row=3, column=0)
        tk.Label(form, text="Partidos Ganados:", bg=bg_color, fg=fg_color).grid(row=4, column=0)
        tk.Label(form, text="Partidos Empatados:", bg=bg_color, fg=fg_color).grid(row=5, column=0)
        tk.Label(form, text="Partidos Perdidos:", bg=bg_color, fg=fg_color).grid(row=6, column=0)
        tk.Label(form, text="Goles a Favor:", bg=bg_color, fg=fg_color).grid(row=7, column=0)
        tk.Label(form, text="Goles en Contra:", bg=bg_color, fg=fg_color).grid(row=8, column=0)
        tk.Label(form, text="Puntos:", bg=bg_color, fg=fg_color).grid(row=9, column=0)

        entry_jornada = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_equipo_id = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_partidos_jugados = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_partidos_ganados = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_partidos_empatados = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_partidos_perdidos = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_goles_a_favor = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_goles_en_contra = tk.Entry(form, bg=frame_color, fg=fg_color)
        entry_puntos = tk.Entry(form, bg=frame_color, fg=fg_color)

        entry_jornada.grid(row=1, column=1)
        entry_equipo_id.grid(row=2, column=1)
        entry_partidos_jugados.grid(row=3, column=1)
        entry_partidos_ganados.grid(row=4, column=1)
        entry_partidos_empatados.grid(row=5, column=1)
        entry_partidos_perdidos.grid(row=6, column=1)
        entry_goles_a_favor.grid(row=7, column=1)
        entry_goles_en_contra.grid(row=8, column=1)
        entry_puntos.grid(row=9, column=1)

        tk.Button(form, text="Actualizar", command=submit, bg=button_color, fg=fg_color).grid(row=10, column=0, columnspan=2)

    # Inicializar la ventana principal
    root.mainloop()

if __name__ == "__main__":
    create_main_window()

